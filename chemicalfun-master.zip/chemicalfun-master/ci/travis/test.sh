./build/tests/test_main
#conda activate chemicalfun
#pytest -ra -vv .
